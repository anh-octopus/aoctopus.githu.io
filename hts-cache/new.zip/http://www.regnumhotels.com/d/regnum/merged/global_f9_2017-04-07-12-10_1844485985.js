
/***************  templates/main/libs/modernizr.custom.js  ***************/
/*! modernizr 3.3.1 (Custom Build) | MIT *
 * http://modernizr.com/download/?-cssgradients-matchmedia-mediaqueries-svg-touchevents-setclasses !*/
!function(e,t,n){function r(e,t){return typeof e===t}function o(){var e,t,n,o,i,s,a;for(var f in y)if(y.hasOwnProperty(f)){if(e=[],t=y[f],t.name&&(e.push(t.name.toLowerCase()),t.options&&t.options.aliases&&t.options.aliases.length))for(n=0;n<t.options.aliases.length;n++)e.push(t.options.aliases[n].toLowerCase());for(o=r(t.fn,"function")?t.fn():t.fn,i=0;i<e.length;i++)s=e[i],a=s.split("."),1===a.length?Modernizr[a[0]]=o:(!Modernizr[a[0]]||Modernizr[a[0]]instanceof Boolean||(Modernizr[a[0]]=new Boolean(Modernizr[a[0]])),Modernizr[a[0]][a[1]]=o),g.push((o?"":"no-")+a.join("-"))}}function i(e){var t=w.className,n=Modernizr._config.classPrefix||"";if(S&&(t=t.baseVal),Modernizr._config.enableJSClass){var r=new RegExp("(^|\\s)"+n+"no-js(\\s|$)");t=t.replace(r,"$1"+n+"js$2")}Modernizr._config.enableClasses&&(t+=" "+n+e.join(" "+n),S?w.className.baseVal=t:w.className=t)}function s(e){return e.replace(/([a-z])-([a-z])/g,function(e,t,n){return t+n.toUpperCase()}).replace(/^-/,"")}function a(){return"function"!=typeof t.createElement?t.createElement(arguments[0]):S?t.createElementNS.call(t,"http://www.w3.org/2000/svg",arguments[0]):t.createElement.apply(t,arguments)}function f(){var e=t.body;return e||(e=a(S?"svg":"body"),e.fake=!0),e}function u(e,n,r,o){var i,s,u,l,d="modernizr",c=a("div"),p=f();if(parseInt(r,10))for(;r--;)u=a("div"),u.id=o?o[r]:d+(r+1),c.appendChild(u);return i=a("style"),i.type="text/css",i.id="s"+d,(p.fake?p:c).appendChild(i),p.appendChild(c),i.styleSheet?i.styleSheet.cssText=e:i.appendChild(t.createTextNode(e)),c.id=d,p.fake&&(p.style.background="",p.style.overflow="hidden",l=w.style.overflow,w.style.overflow="hidden",w.appendChild(p)),s=n(c,e),p.fake?(p.parentNode.removeChild(p),w.style.overflow=l,w.offsetHeight):c.parentNode.removeChild(c),!!s}function l(e,t){return!!~(""+e).indexOf(t)}function d(e,t){return function(){return e.apply(t,arguments)}}function c(e,t,n){var o;for(var i in e)if(e[i]in t)return n===!1?e[i]:(o=t[e[i]],r(o,"function")?d(o,n||t):o);return!1}function p(e){return e.replace(/([A-Z])/g,function(e,t){return"-"+t.toLowerCase()}).replace(/^ms-/,"-ms-")}function m(t,r){var o=t.length;if("CSS"in e&&"supports"in e.CSS){for(;o--;)if(e.CSS.supports(p(t[o]),r))return!0;return!1}if("CSSSupportsRule"in e){for(var i=[];o--;)i.push("("+p(t[o])+":"+r+")");return i=i.join(" or "),u("@supports ("+i+") { #modernizr { position: absolute; } }",function(e){return"absolute"==getComputedStyle(e,null).position})}return n}function v(e,t,o,i){function f(){d&&(delete k.style,delete k.modElem)}if(i=r(i,"undefined")?!1:i,!r(o,"undefined")){var u=m(e,o);if(!r(u,"undefined"))return u}for(var d,c,p,v,h,g=["modernizr","tspan"];!k.style;)d=!0,k.modElem=a(g.shift()),k.style=k.modElem.style;for(p=e.length,c=0;p>c;c++)if(v=e[c],h=k.style[v],l(v,"-")&&(v=s(v)),k.style[v]!==n){if(i||r(o,"undefined"))return f(),"pfx"==t?v:!0;try{k.style[v]=o}catch(y){}if(k.style[v]!=h)return f(),"pfx"==t?v:!0}return f(),!1}function h(e,t,n,o,i){var s=e.charAt(0).toUpperCase()+e.slice(1),a=(e+" "+z.join(s+" ")+s).split(" ");return r(t,"string")||r(t,"undefined")?v(a,t,o,i):(a=(e+" "+N.join(s+" ")+s).split(" "),c(a,t,n))}var g=[],y=[],C={_version:"3.3.1",_config:{classPrefix:"",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,t){var n=this;setTimeout(function(){t(n[e])},0)},addTest:function(e,t,n){y.push({name:e,fn:t,options:n})},addAsyncTest:function(e){y.push({name:null,fn:e})}},Modernizr=function(){};Modernizr.prototype=C,Modernizr=new Modernizr,Modernizr.addTest("svg",!!t.createElementNS&&!!t.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect);var w=t.documentElement,S="svg"===w.nodeName.toLowerCase(),x=C._config.usePrefixes?" -webkit- -moz- -o- -ms- ".split(" "):["",""];C._prefixes=x;var _=C.testStyles=u;Modernizr.addTest("touchevents",function(){var n;if("ontouchstart"in e||e.DocumentTouch&&t instanceof DocumentTouch)n=!0;else{var r=["@media (",x.join("touch-enabled),("),"heartz",")","{#modernizr{top:9px;position:absolute}}"].join("");_(r,function(e){n=9===e.offsetTop})}return n});var b=function(){var t=e.matchMedia||e.msMatchMedia;return t?function(e){var n=t(e);return n&&n.matches||!1}:function(t){var n=!1;return u("@media "+t+" { #modernizr { position: absolute; } }",function(t){n="absolute"==(e.getComputedStyle?e.getComputedStyle(t,null):t.currentStyle).position}),n}}();C.mq=b,Modernizr.addTest("mediaqueries",b("only all")),Modernizr.addTest("cssgradients",function(){for(var e,t="background-image:",n="gradient(linear,left top,right bottom,from(#9f9),to(white));",r="",o=0,i=x.length-1;i>o;o++)e=0===o?"to ":"",r+=t+x[o]+"linear-gradient("+e+"left top, #9f9, white);";Modernizr._config.usePrefixes&&(r+=t+"-webkit-"+n);var s=a("a"),f=s.style;return f.cssText=r,(""+f.backgroundImage).indexOf("gradient")>-1});var T="Moz O ms Webkit",z=C._config.usePrefixes?T.split(" "):[];C._cssomPrefixes=z;var E=function(t){var r,o=x.length,i=e.CSSRule;if("undefined"==typeof i)return n;if(!t)return!1;if(t=t.replace(/^@/,""),r=t.replace(/-/g,"_").toUpperCase()+"_RULE",r in i)return"@"+t;for(var s=0;o>s;s++){var a=x[s],f=a.toUpperCase()+"_"+r;if(f in i)return"@-"+a.toLowerCase()+"-"+t}return!1};C.atRule=E;var N=C._config.usePrefixes?T.toLowerCase().split(" "):[];C._domPrefixes=N;var P={elem:a("modernizr")};Modernizr._q.push(function(){delete P.elem});var k={style:P.elem.style};Modernizr._q.unshift(function(){delete k.style}),C.testAllProps=h;var j=C.prefixed=function(e,t,n){return 0===e.indexOf("@")?E(e):(-1!=e.indexOf("-")&&(e=s(e)),t?h(e,t,n):h(e,"pfx"))};Modernizr.addTest("matchmedia",!!j("matchMedia",e)),o(),i(g),delete C.addTest,delete C.addAsyncTest;for(var q=0;q<Modernizr._q.length;q++)Modernizr._q[q]();e.Modernizr=Modernizr}(window,document);
/***************  templates/main/libs/jquery/respond.min.js  ***************/
/*! matchMedia() polyfill - Test a CSS media type/query in JS. Authors & copyright (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas. Dual MIT/BSD license */
/*! NOTE: If you're already including a window.matchMedia polyfill via Modernizr or otherwise, you don't need this part */
window.matchMedia=window.matchMedia||function(a){"use strict";var c,d=a.documentElement,e=d.firstElementChild||d.firstChild,f=a.createElement("body"),g=a.createElement("div");return g.id="mq-test-1",g.style.cssText="position:absolute;top:-100em",f.style.background="none",f.appendChild(g),function(a){return g.innerHTML='&shy;<style media="'+a+'"> #mq-test-1 { width: 42px; }</style>',d.insertBefore(f,e),c=42===g.offsetWidth,d.removeChild(f),{matches:c,media:a}}}(document);

/*! Respond.js v1.1.0: min/max-width media query polyfill. (c) Scott Jehl. MIT/GPLv2 Lic. j.mp/respondjs  */
(function(a){"use strict";function x(){u(!0)}var b={};if(a.respond=b,b.update=function(){},b.mediaQueriesSupported=a.matchMedia&&a.matchMedia("only all").matches,!b.mediaQueriesSupported){var q,r,t,c=a.document,d=c.documentElement,e=[],f=[],g=[],h={},i=30,j=c.getElementsByTagName("head")[0]||d,k=c.getElementsByTagName("base")[0],l=j.getElementsByTagName("link"),m=[],n=function(){for(var b=0;l.length>b;b++){var c=l[b],d=c.href,e=c.media,f=c.rel&&"stylesheet"===c.rel.toLowerCase();d&&f&&!h[d]&&(c.styleSheet&&c.styleSheet.rawCssText?(p(c.styleSheet.rawCssText,d,e),h[d]=!0):(!/^([a-zA-Z:]*\/\/)/.test(d)&&!k||d.replace(RegExp.$1,"").split("/")[0]===a.location.host)&&m.push({href:d,media:e}))}o()},o=function(){if(m.length){var b=m.shift();v(b.href,function(c){p(c,b.href,b.media),h[b.href]=!0,a.setTimeout(function(){o()},0)})}},p=function(a,b,c){var d=a.match(/@media[^\{]+\{([^\{\}]*\{[^\}\{]*\})+/gi),g=d&&d.length||0;b=b.substring(0,b.lastIndexOf("/"));var h=function(a){return a.replace(/(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g,"$1"+b+"$2$3")},i=!g&&c;b.length&&(b+="/"),i&&(g=1);for(var j=0;g>j;j++){var k,l,m,n;i?(k=c,f.push(h(a))):(k=d[j].match(/@media *([^\{]+)\{([\S\s]+?)$/)&&RegExp.$1,f.push(RegExp.$2&&h(RegExp.$2))),m=k.split(","),n=m.length;for(var o=0;n>o;o++)l=m[o],e.push({media:l.split("(")[0].match(/(only\s+)?([a-zA-Z]+)\s?/)&&RegExp.$2||"all",rules:f.length-1,hasquery:l.indexOf("(")>-1,minw:l.match(/\(\s*min\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/)&&parseFloat(RegExp.$1)+(RegExp.$2||""),maxw:l.match(/\(\s*max\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/)&&parseFloat(RegExp.$1)+(RegExp.$2||"")})}u()},s=function(){var a,b=c.createElement("div"),e=c.body,f=!1;return b.style.cssText="position:absolute;font-size:1em;width:1em",e||(e=f=c.createElement("body"),e.style.background="none"),e.appendChild(b),d.insertBefore(e,d.firstChild),a=b.offsetWidth,f?d.removeChild(e):e.removeChild(b),a=t=parseFloat(a)},u=function(b){var h="clientWidth",k=d[h],m="CSS1Compat"===c.compatMode&&k||c.body[h]||k,n={},o=l[l.length-1],p=(new Date).getTime();if(b&&q&&i>p-q)return a.clearTimeout(r),r=a.setTimeout(u,i),void 0;q=p;for(var v in e)if(e.hasOwnProperty(v)){var w=e[v],x=w.minw,y=w.maxw,z=null===x,A=null===y,B="em";x&&(x=parseFloat(x)*(x.indexOf(B)>-1?t||s():1)),y&&(y=parseFloat(y)*(y.indexOf(B)>-1?t||s():1)),w.hasquery&&(z&&A||!(z||m>=x)||!(A||y>=m))||(n[w.media]||(n[w.media]=[]),n[w.media].push(f[w.rules]))}for(var C in g)g.hasOwnProperty(C)&&g[C]&&g[C].parentNode===j&&j.removeChild(g[C]);for(var D in n)if(n.hasOwnProperty(D)){var E=c.createElement("style"),F=n[D].join("\n");E.type="text/css",E.media=D,j.insertBefore(E,o.nextSibling),E.styleSheet?E.styleSheet.cssText=F:E.appendChild(c.createTextNode(F)),g.push(E)}},v=function(a,b){var c=w();c&&(c.open("GET",a,!0),c.onreadystatechange=function(){4!==c.readyState||200!==c.status&&304!==c.status||b(c.responseText)},4!==c.readyState&&c.send(null))},w=function(){var b=!1;try{b=new a.XMLHttpRequest}catch(c){b=new a.ActiveXObject("Microsoft.XMLHTTP")}return function(){return b}}();n(),b.update=n,a.addEventListener?a.addEventListener("resize",x,!1):a.attachEvent&&a.attachEvent("onresize",x)}})(this);

/***************  templates/main/libs/jquery/cycle/jquery.cycle2.min.js  ***************/
/*!
* jQuery Cycle2; version: 2.1.6 build: 20141007
* http://jquery.malsup.com/cycle2/
* Copyright (c) 2014 M. Alsup; Dual licensed: MIT/GPL
*/
!function(a){"use strict";function b(a){return(a||"").toLowerCase()}var c="2.1.6";a.fn.cycle=function(c){var d;return 0!==this.length||a.isReady?this.each(function(){var d,e,f,g,h=a(this),i=a.fn.cycle.log;if(!h.data("cycle.opts")){(h.data("cycle-log")===!1||c&&c.log===!1||e&&e.log===!1)&&(i=a.noop),i("--c2 init--"),d=h.data();for(var j in d)d.hasOwnProperty(j)&&/^cycle[A-Z]+/.test(j)&&(g=d[j],f=j.match(/^cycle(.*)/)[1].replace(/^[A-Z]/,b),i(f+":",g,"("+typeof g+")"),d[f]=g);e=a.extend({},a.fn.cycle.defaults,d,c||{}),e.timeoutId=0,e.paused=e.paused||!1,e.container=h,e._maxZ=e.maxZ,e.API=a.extend({_container:h},a.fn.cycle.API),e.API.log=i,e.API.trigger=function(a,b){return e.container.trigger(a,b),e.API},h.data("cycle.opts",e),h.data("cycle.API",e.API),e.API.trigger("cycle-bootstrap",[e,e.API]),e.API.addInitialSlides(),e.API.preInitSlideshow(),e.slides.length&&e.API.initSlideshow()}}):(d={s:this.selector,c:this.context},a.fn.cycle.log("requeuing slideshow (dom not ready)"),a(function(){a(d.s,d.c).cycle(c)}),this)},a.fn.cycle.API={opts:function(){return this._container.data("cycle.opts")},addInitialSlides:function(){var b=this.opts(),c=b.slides;b.slideCount=0,b.slides=a(),c=c.jquery?c:b.container.find(c),b.random&&c.sort(function(){return Math.random()-.5}),b.API.add(c)},preInitSlideshow:function(){var b=this.opts();b.API.trigger("cycle-pre-initialize",[b]);var c=a.fn.cycle.transitions[b.fx];c&&a.isFunction(c.preInit)&&c.preInit(b),b._preInitialized=!0},postInitSlideshow:function(){var b=this.opts();b.API.trigger("cycle-post-initialize",[b]);var c=a.fn.cycle.transitions[b.fx];c&&a.isFunction(c.postInit)&&c.postInit(b)},initSlideshow:function(){var b,c=this.opts(),d=c.container;c.API.calcFirstSlide(),"static"==c.container.css("position")&&c.container.css("position","relative"),a(c.slides[c.currSlide]).css({opacity:1,display:"block",visibility:"visible"}),c.API.stackSlides(c.slides[c.currSlide],c.slides[c.nextSlide],!c.reverse),c.pauseOnHover&&(c.pauseOnHover!==!0&&(d=a(c.pauseOnHover)),d.hover(function(){c.API.pause(!0)},function(){c.API.resume(!0)})),c.timeout&&(b=c.API.getSlideOpts(c.currSlide),c.API.queueTransition(b,b.timeout+c.delay)),c._initialized=!0,c.API.updateView(!0),c.API.trigger("cycle-initialized",[c]),c.API.postInitSlideshow()},pause:function(b){var c=this.opts(),d=c.API.getSlideOpts(),e=c.hoverPaused||c.paused;b?c.hoverPaused=!0:c.paused=!0,e||(c.container.addClass("cycle-paused"),c.API.trigger("cycle-paused",[c]).log("cycle-paused"),d.timeout&&(clearTimeout(c.timeoutId),c.timeoutId=0,c._remainingTimeout-=a.now()-c._lastQueue,(c._remainingTimeout<0||isNaN(c._remainingTimeout))&&(c._remainingTimeout=void 0)))},resume:function(a){var b=this.opts(),c=!b.hoverPaused&&!b.paused;a?b.hoverPaused=!1:b.paused=!1,c||(b.container.removeClass("cycle-paused"),0===b.slides.filter(":animated").length&&b.API.queueTransition(b.API.getSlideOpts(),b._remainingTimeout),b.API.trigger("cycle-resumed",[b,b._remainingTimeout]).log("cycle-resumed"))},add:function(b,c){var d,e=this.opts(),f=e.slideCount,g=!1;"string"==a.type(b)&&(b=a.trim(b)),a(b).each(function(){var b,d=a(this);c?e.container.prepend(d):e.container.append(d),e.slideCount++,b=e.API.buildSlideOpts(d),e.slides=c?a(d).add(e.slides):e.slides.add(d),e.API.initSlide(b,d,--e._maxZ),d.data("cycle.opts",b),e.API.trigger("cycle-slide-added",[e,b,d])}),e.API.updateView(!0),g=e._preInitialized&&2>f&&e.slideCount>=1,g&&(e._initialized?e.timeout&&(d=e.slides.length,e.nextSlide=e.reverse?d-1:1,e.timeoutId||e.API.queueTransition(e)):e.API.initSlideshow())},calcFirstSlide:function(){var a,b=this.opts();a=parseInt(b.startingSlide||0,10),(a>=b.slides.length||0>a)&&(a=0),b.currSlide=a,b.reverse?(b.nextSlide=a-1,b.nextSlide<0&&(b.nextSlide=b.slides.length-1)):(b.nextSlide=a+1,b.nextSlide==b.slides.length&&(b.nextSlide=0))},calcNextSlide:function(){var a,b=this.opts();b.reverse?(a=b.nextSlide-1<0,b.nextSlide=a?b.slideCount-1:b.nextSlide-1,b.currSlide=a?0:b.nextSlide+1):(a=b.nextSlide+1==b.slides.length,b.nextSlide=a?0:b.nextSlide+1,b.currSlide=a?b.slides.length-1:b.nextSlide-1)},calcTx:function(b,c){var d,e=b;return e._tempFx?d=a.fn.cycle.transitions[e._tempFx]:c&&e.manualFx&&(d=a.fn.cycle.transitions[e.manualFx]),d||(d=a.fn.cycle.transitions[e.fx]),e._tempFx=null,this.opts()._tempFx=null,d||(d=a.fn.cycle.transitions.fade,e.API.log('Transition "'+e.fx+'" not found.  Using fade.')),d},prepareTx:function(a,b){var c,d,e,f,g,h=this.opts();return h.slideCount<2?void(h.timeoutId=0):(!a||h.busy&&!h.manualTrump||(h.API.stopTransition(),h.busy=!1,clearTimeout(h.timeoutId),h.timeoutId=0),void(h.busy||(0!==h.timeoutId||a)&&(d=h.slides[h.currSlide],e=h.slides[h.nextSlide],f=h.API.getSlideOpts(h.nextSlide),g=h.API.calcTx(f,a),h._tx=g,a&&void 0!==f.manualSpeed&&(f.speed=f.manualSpeed),h.nextSlide!=h.currSlide&&(a||!h.paused&&!h.hoverPaused&&h.timeout)?(h.API.trigger("cycle-before",[f,d,e,b]),g.before&&g.before(f,d,e,b),c=function(){h.busy=!1,h.container.data("cycle.opts")&&(g.after&&g.after(f,d,e,b),h.API.trigger("cycle-after",[f,d,e,b]),h.API.queueTransition(f),h.API.updateView(!0))},h.busy=!0,g.transition?g.transition(f,d,e,b,c):h.API.doTransition(f,d,e,b,c),h.API.calcNextSlide(),h.API.updateView()):h.API.queueTransition(f))))},doTransition:function(b,c,d,e,f){var g=b,h=a(c),i=a(d),j=function(){i.animate(g.animIn||{opacity:1},g.speed,g.easeIn||g.easing,f)};i.css(g.cssBefore||{}),h.animate(g.animOut||{},g.speed,g.easeOut||g.easing,function(){h.css(g.cssAfter||{}),g.sync||j()}),g.sync&&j()},queueTransition:function(b,c){var d=this.opts(),e=void 0!==c?c:b.timeout;return 0===d.nextSlide&&0===--d.loop?(d.API.log("terminating; loop=0"),d.timeout=0,e?setTimeout(function(){d.API.trigger("cycle-finished",[d])},e):d.API.trigger("cycle-finished",[d]),void(d.nextSlide=d.currSlide)):void 0!==d.continueAuto&&(d.continueAuto===!1||a.isFunction(d.continueAuto)&&d.continueAuto()===!1)?(d.API.log("terminating automatic transitions"),d.timeout=0,void(d.timeoutId&&clearTimeout(d.timeoutId))):void(e&&(d._lastQueue=a.now(),void 0===c&&(d._remainingTimeout=b.timeout),d.paused||d.hoverPaused||(d.timeoutId=setTimeout(function(){d.API.prepareTx(!1,!d.reverse)},e))))},stopTransition:function(){var a=this.opts();a.slides.filter(":animated").length&&(a.slides.stop(!1,!0),a.API.trigger("cycle-transition-stopped",[a])),a._tx&&a._tx.stopTransition&&a._tx.stopTransition(a)},advanceSlide:function(a){var b=this.opts();return clearTimeout(b.timeoutId),b.timeoutId=0,b.nextSlide=b.currSlide+a,b.nextSlide<0?b.nextSlide=b.slides.length-1:b.nextSlide>=b.slides.length&&(b.nextSlide=0),b.API.prepareTx(!0,a>=0),!1},buildSlideOpts:function(c){var d,e,f=this.opts(),g=c.data()||{};for(var h in g)g.hasOwnProperty(h)&&/^cycle[A-Z]+/.test(h)&&(d=g[h],e=h.match(/^cycle(.*)/)[1].replace(/^[A-Z]/,b),f.API.log("["+(f.slideCount-1)+"]",e+":",d,"("+typeof d+")"),g[e]=d);g=a.extend({},a.fn.cycle.defaults,f,g),g.slideNum=f.slideCount;try{delete g.API,delete g.slideCount,delete g.currSlide,delete g.nextSlide,delete g.slides}catch(i){}return g},getSlideOpts:function(b){var c=this.opts();void 0===b&&(b=c.currSlide);var d=c.slides[b],e=a(d).data("cycle.opts");return a.extend({},c,e)},initSlide:function(b,c,d){var e=this.opts();c.css(b.slideCss||{}),d>0&&c.css("zIndex",d),isNaN(b.speed)&&(b.speed=a.fx.speeds[b.speed]||a.fx.speeds._default),b.sync||(b.speed=b.speed/2),c.addClass(e.slideClass)},updateView:function(a,b){var c=this.opts();if(c._initialized){var d=c.API.getSlideOpts(),e=c.slides[c.currSlide];!a&&b!==!0&&(c.API.trigger("cycle-update-view-before",[c,d,e]),c.updateView<0)||(c.slideActiveClass&&c.slides.removeClass(c.slideActiveClass).eq(c.currSlide).addClass(c.slideActiveClass),a&&c.hideNonActive&&c.slides.filter(":not(."+c.slideActiveClass+")").css("visibility","hidden"),0===c.updateView&&setTimeout(function(){c.API.trigger("cycle-update-view",[c,d,e,a])},d.speed/(c.sync?2:1)),0!==c.updateView&&c.API.trigger("cycle-update-view",[c,d,e,a]),a&&c.API.trigger("cycle-update-view-after",[c,d,e]))}},getComponent:function(b){var c=this.opts(),d=c[b];return"string"==typeof d?/^\s*[\>|\+|~]/.test(d)?c.container.find(d):a(d):d.jquery?d:a(d)},stackSlides:function(b,c,d){var e=this.opts();b||(b=e.slides[e.currSlide],c=e.slides[e.nextSlide],d=!e.reverse),a(b).css("zIndex",e.maxZ);var f,g=e.maxZ-2,h=e.slideCount;if(d){for(f=e.currSlide+1;h>f;f++)a(e.slides[f]).css("zIndex",g--);for(f=0;f<e.currSlide;f++)a(e.slides[f]).css("zIndex",g--)}else{for(f=e.currSlide-1;f>=0;f--)a(e.slides[f]).css("zIndex",g--);for(f=h-1;f>e.currSlide;f--)a(e.slides[f]).css("zIndex",g--)}a(c).css("zIndex",e.maxZ-1)},getSlideIndex:function(a){return this.opts().slides.index(a)}},a.fn.cycle.log=function(){window.console&&console.log&&console.log("[cycle2] "+Array.prototype.join.call(arguments," "))},a.fn.cycle.version=function(){return"Cycle2: "+c},a.fn.cycle.transitions={custom:{},none:{before:function(a,b,c,d){a.API.stackSlides(c,b,d),a.cssBefore={opacity:1,visibility:"visible",display:"block"}}},fade:{before:function(b,c,d,e){var f=b.API.getSlideOpts(b.nextSlide).slideCss||{};b.API.stackSlides(c,d,e),b.cssBefore=a.extend(f,{opacity:0,visibility:"visible",display:"block"}),b.animIn={opacity:1},b.animOut={opacity:0}}},fadeout:{before:function(b,c,d,e){var f=b.API.getSlideOpts(b.nextSlide).slideCss||{};b.API.stackSlides(c,d,e),b.cssBefore=a.extend(f,{opacity:1,visibility:"visible",display:"block"}),b.animOut={opacity:0}}},scrollHorz:{before:function(a,b,c,d){a.API.stackSlides(b,c,d);var e=a.container.css("overflow","hidden").width();a.cssBefore={left:d?e:-e,top:0,opacity:1,visibility:"visible",display:"block"},a.cssAfter={zIndex:a._maxZ-2,left:0},a.animIn={left:0},a.animOut={left:d?-e:e}}}},a.fn.cycle.defaults={allowWrap:!0,autoSelector:".cycle-slideshow[data-cycle-auto-init!=false]",delay:0,easing:null,fx:"fade",hideNonActive:!0,loop:0,manualFx:void 0,manualSpeed:void 0,manualTrump:!0,maxZ:100,pauseOnHover:!1,reverse:!1,slideActiveClass:"cycle-slide-active",slideClass:"cycle-slide",slideCss:{position:"absolute",top:0,left:0},slides:"> img",speed:500,startingSlide:0,sync:!0,timeout:4e3,updateView:0},a(document).ready(function(){a(a.fn.cycle.defaults.autoSelector).cycle()})}(jQuery),/*! Cycle2 autoheight plugin; Copyright (c) M.Alsup, 2012; version: 20130913 */
function(a){"use strict";function b(b,d){var e,f,g,h=d.autoHeight;if("container"==h)f=a(d.slides[d.currSlide]).outerHeight(),d.container.height(f);else if(d._autoHeightRatio)d.container.height(d.container.width()/d._autoHeightRatio);else if("calc"===h||"number"==a.type(h)&&h>=0){if(g="calc"===h?c(b,d):h>=d.slides.length?0:h,g==d._sentinelIndex)return;d._sentinelIndex=g,d._sentinel&&d._sentinel.remove(),e=a(d.slides[g].cloneNode(!0)),e.removeAttr("id name rel").find("[id],[name],[rel]").removeAttr("id name rel"),e.css({position:"static",visibility:"hidden",display:"block"}).prependTo(d.container).addClass("cycle-sentinel cycle-slide").removeClass("cycle-slide-active"),e.find("*").css("visibility","hidden"),d._sentinel=e}}function c(b,c){var d=0,e=-1;return c.slides.each(function(b){var c=a(this).height();c>e&&(e=c,d=b)}),d}function d(b,c,d,e){var f=a(e).outerHeight();c.container.animate({height:f},c.autoHeightSpeed,c.autoHeightEasing)}function e(c,f){f._autoHeightOnResize&&(a(window).off("resize orientationchange",f._autoHeightOnResize),f._autoHeightOnResize=null),f.container.off("cycle-slide-added cycle-slide-removed",b),f.container.off("cycle-destroyed",e),f.container.off("cycle-before",d),f._sentinel&&(f._sentinel.remove(),f._sentinel=null)}a.extend(a.fn.cycle.defaults,{autoHeight:0,autoHeightSpeed:250,autoHeightEasing:null}),a(document).on("cycle-initialized",function(c,f){function g(){b(c,f)}var h,i=f.autoHeight,j=a.type(i),k=null;("string"===j||"number"===j)&&(f.container.on("cycle-slide-added cycle-slide-removed",b),f.container.on("cycle-destroyed",e),"container"==i?f.container.on("cycle-before",d):"string"===j&&/\d+\:\d+/.test(i)&&(h=i.match(/(\d+)\:(\d+)/),h=h[1]/h[2],f._autoHeightRatio=h),"number"!==j&&(f._autoHeightOnResize=function(){clearTimeout(k),k=setTimeout(g,50)},a(window).on("resize orientationchange",f._autoHeightOnResize)),setTimeout(g,30))})}(jQuery),/*! caption plugin for Cycle2;  version: 20130306 */
function(a){"use strict";a.extend(a.fn.cycle.defaults,{caption:"> .cycle-caption",captionTemplate:"{{slideNum}} / {{slideCount}}",overlay:"> .cycle-overlay",overlayTemplate:"<div>{{title}}</div><div>{{desc}}</div>",captionModule:"caption"}),a(document).on("cycle-update-view",function(b,c,d,e){if("caption"===c.captionModule){a.each(["caption","overlay"],function(){var a=this,b=d[a+"Template"],f=c.API.getComponent(a);f.length&&b?(f.html(c.API.tmpl(b,d,c,e)),f.show()):f.hide()})}}),a(document).on("cycle-destroyed",function(b,c){var d;a.each(["caption","overlay"],function(){var a=this,b=c[a+"Template"];c[a]&&b&&(d=c.API.getComponent("caption"),d.empty())})})}(jQuery),/*! command plugin for Cycle2;  version: 20140415 */
function(a){"use strict";var b=a.fn.cycle;a.fn.cycle=function(c){var d,e,f,g=a.makeArray(arguments);return"number"==a.type(c)?this.cycle("goto",c):"string"==a.type(c)?this.each(function(){var h;return d=c,f=a(this).data("cycle.opts"),void 0===f?void b.log('slideshow must be initialized before sending commands; "'+d+'" ignored'):(d="goto"==d?"jump":d,e=f.API[d],a.isFunction(e)?(h=a.makeArray(g),h.shift(),e.apply(f.API,h)):void b.log("unknown command: ",d))}):b.apply(this,arguments)},a.extend(a.fn.cycle,b),a.extend(b.API,{next:function(){var a=this.opts();if(!a.busy||a.manualTrump){var b=a.reverse?-1:1;a.allowWrap===!1&&a.currSlide+b>=a.slideCount||(a.API.advanceSlide(b),a.API.trigger("cycle-next",[a]).log("cycle-next"))}},prev:function(){var a=this.opts();if(!a.busy||a.manualTrump){var b=a.reverse?1:-1;a.allowWrap===!1&&a.currSlide+b<0||(a.API.advanceSlide(b),a.API.trigger("cycle-prev",[a]).log("cycle-prev"))}},destroy:function(){this.stop();var b=this.opts(),c=a.isFunction(a._data)?a._data:a.noop;clearTimeout(b.timeoutId),b.timeoutId=0,b.API.stop(),b.API.trigger("cycle-destroyed",[b]).log("cycle-destroyed"),b.container.removeData(),c(b.container[0],"parsedAttrs",!1),b.retainStylesOnDestroy||(b.container.removeAttr("style"),b.slides.removeAttr("style"),b.slides.removeClass(b.slideActiveClass)),b.slides.each(function(){var d=a(this);d.removeData(),d.removeClass(b.slideClass),c(this,"parsedAttrs",!1)})},jump:function(a,b){var c,d=this.opts();if(!d.busy||d.manualTrump){var e=parseInt(a,10);if(isNaN(e)||0>e||e>=d.slides.length)return void d.API.log("goto: invalid slide index: "+e);if(e==d.currSlide)return void d.API.log("goto: skipping, already on slide",e);d.nextSlide=e,clearTimeout(d.timeoutId),d.timeoutId=0,d.API.log("goto: ",e," (zero-index)"),c=d.currSlide<d.nextSlide,d._tempFx=b,d.API.prepareTx(!0,c)}},stop:function(){var b=this.opts(),c=b.container;clearTimeout(b.timeoutId),b.timeoutId=0,b.API.stopTransition(),b.pauseOnHover&&(b.pauseOnHover!==!0&&(c=a(b.pauseOnHover)),c.off("mouseenter mouseleave")),b.API.trigger("cycle-stopped",[b]).log("cycle-stopped")},reinit:function(){var a=this.opts();a.API.destroy(),a.container.cycle()},remove:function(b){for(var c,d,e=this.opts(),f=[],g=1,h=0;h<e.slides.length;h++)c=e.slides[h],h==b?d=c:(f.push(c),a(c).data("cycle.opts").slideNum=g,g++);d&&(e.slides=a(f),e.slideCount--,a(d).remove(),b==e.currSlide?e.API.advanceSlide(1):b<e.currSlide?e.currSlide--:e.currSlide++,e.API.trigger("cycle-slide-removed",[e,b,d]).log("cycle-slide-removed"),e.API.updateView())}}),a(document).on("click.cycle","[data-cycle-cmd]",function(b){b.preventDefault();var c=a(this),d=c.data("cycle-cmd"),e=c.data("cycle-context")||".cycle-slideshow";a(e).cycle(d,c.data("cycle-arg"))})}(jQuery),/*! hash plugin for Cycle2;  version: 20130905 */
function(a){"use strict";function b(b,c){var d;return b._hashFence?void(b._hashFence=!1):(d=window.location.hash.substring(1),void b.slides.each(function(e){if(a(this).data("cycle-hash")==d){if(c===!0)b.startingSlide=e;else{var f=b.currSlide<e;b.nextSlide=e,b.API.prepareTx(!0,f)}return!1}}))}a(document).on("cycle-pre-initialize",function(c,d){b(d,!0),d._onHashChange=function(){b(d,!1)},a(window).on("hashchange",d._onHashChange)}),a(document).on("cycle-update-view",function(a,b,c){c.hash&&"#"+c.hash!=window.location.hash&&(b._hashFence=!0,window.location.hash=c.hash)}),a(document).on("cycle-destroyed",function(b,c){c._onHashChange&&a(window).off("hashchange",c._onHashChange)})}(jQuery),/*! loader plugin for Cycle2;  version: 20131121 */
function(a){"use strict";a.extend(a.fn.cycle.defaults,{loader:!1}),a(document).on("cycle-bootstrap",function(b,c){function d(b,d){function f(b){var f;"wait"==c.loader?(h.push(b),0===j&&(h.sort(g),e.apply(c.API,[h,d]),c.container.removeClass("cycle-loading"))):(f=a(c.slides[c.currSlide]),e.apply(c.API,[b,d]),f.show(),c.container.removeClass("cycle-loading"))}function g(a,b){return a.data("index")-b.data("index")}var h=[];if("string"==a.type(b))b=a.trim(b);else if("array"===a.type(b))for(var i=0;i<b.length;i++)b[i]=a(b[i])[0];b=a(b);var j=b.length;j&&(b.css("visibility","hidden").appendTo("body").each(function(b){function g(){0===--i&&(--j,f(k))}var i=0,k=a(this),l=k.is("img")?k:k.find("img");return k.data("index",b),l=l.filter(":not(.cycle-loader-ignore)").filter(':not([src=""])'),l.length?(i=l.length,void l.each(function(){this.complete?g():a(this).load(function(){g()}).on("error",function(){0===--i&&(c.API.log("slide skipped; img not loaded:",this.src),0===--j&&"wait"==c.loader&&e.apply(c.API,[h,d]))})})):(--j,void h.push(k))}),j&&c.container.addClass("cycle-loading"))}var e;c.loader&&(e=c.API.add,c.API.add=d)})}(jQuery),/*! pager plugin for Cycle2;  version: 20140415 */
function(a){"use strict";function b(b,c,d){var e,f=b.API.getComponent("pager");f.each(function(){var f=a(this);if(c.pagerTemplate){var g=b.API.tmpl(c.pagerTemplate,c,b,d[0]);e=a(g).appendTo(f)}else e=f.children().eq(b.slideCount-1);e.on(b.pagerEvent,function(a){b.pagerEventBubble||a.preventDefault(),b.API.page(f,a.currentTarget)})})}function c(a,b){var c=this.opts();if(!c.busy||c.manualTrump){var d=a.children().index(b),e=d,f=c.currSlide<e;c.currSlide!=e&&(c.nextSlide=e,c._tempFx=c.pagerFx,c.API.prepareTx(!0,f),c.API.trigger("cycle-pager-activated",[c,a,b]))}}a.extend(a.fn.cycle.defaults,{pager:"> .cycle-pager",pagerActiveClass:"cycle-pager-active",pagerEvent:"click.cycle",pagerEventBubble:void 0,pagerTemplate:"<span>&bull;</span>"}),a(document).on("cycle-bootstrap",function(a,c,d){d.buildPagerLink=b}),a(document).on("cycle-slide-added",function(a,b,d,e){b.pager&&(b.API.buildPagerLink(b,d,e),b.API.page=c)}),a(document).on("cycle-slide-removed",function(b,c,d){if(c.pager){var e=c.API.getComponent("pager");e.each(function(){var b=a(this);a(b.children()[d]).remove()})}}),a(document).on("cycle-update-view",function(b,c){var d;c.pager&&(d=c.API.getComponent("pager"),d.each(function(){a(this).children().removeClass(c.pagerActiveClass).eq(c.currSlide).addClass(c.pagerActiveClass)}))}),a(document).on("cycle-destroyed",function(a,b){var c=b.API.getComponent("pager");c&&(c.children().off(b.pagerEvent),b.pagerTemplate&&c.empty())})}(jQuery),/*! prevnext plugin for Cycle2;  version: 20140408 */
function(a){"use strict";a.extend(a.fn.cycle.defaults,{next:"> .cycle-next",nextEvent:"click.cycle",disabledClass:"disabled",prev:"> .cycle-prev",prevEvent:"click.cycle",swipe:!1}),a(document).on("cycle-initialized",function(a,b){if(b.API.getComponent("next").on(b.nextEvent,function(a){a.preventDefault(),b.API.next()}),b.API.getComponent("prev").on(b.prevEvent,function(a){a.preventDefault(),b.API.prev()}),b.swipe){var c=b.swipeVert?"swipeUp.cycle":"swipeLeft.cycle swipeleft.cycle",d=b.swipeVert?"swipeDown.cycle":"swipeRight.cycle swiperight.cycle";b.container.on(c,function(){b._tempFx=b.swipeFx,b.API.next()}),b.container.on(d,function(){b._tempFx=b.swipeFx,b.API.prev()})}}),a(document).on("cycle-update-view",function(a,b){if(!b.allowWrap){var c=b.disabledClass,d=b.API.getComponent("next"),e=b.API.getComponent("prev"),f=b._prevBoundry||0,g=void 0!==b._nextBoundry?b._nextBoundry:b.slideCount-1;b.currSlide==g?d.addClass(c).prop("disabled",!0):d.removeClass(c).prop("disabled",!1),b.currSlide===f?e.addClass(c).prop("disabled",!0):e.removeClass(c).prop("disabled",!1)}}),a(document).on("cycle-destroyed",function(a,b){b.API.getComponent("prev").off(b.nextEvent),b.API.getComponent("next").off(b.prevEvent),b.container.off("swipeleft.cycle swiperight.cycle swipeLeft.cycle swipeRight.cycle swipeUp.cycle swipeDown.cycle")})}(jQuery),/*! progressive loader plugin for Cycle2;  version: 20130315 */
function(a){"use strict";a.extend(a.fn.cycle.defaults,{progressive:!1}),a(document).on("cycle-pre-initialize",function(b,c){if(c.progressive){var d,e,f=c.API,g=f.next,h=f.prev,i=f.prepareTx,j=a.type(c.progressive);if("array"==j)d=c.progressive;else if(a.isFunction(c.progressive))d=c.progressive(c);else if("string"==j){if(e=a(c.progressive),d=a.trim(e.html()),!d)return;if(/^(\[)/.test(d))try{d=a.parseJSON(d)}catch(k){return void f.log("error parsing progressive slides",k)}else d=d.split(new RegExp(e.data("cycle-split")||"\n")),d[d.length-1]||d.pop()}i&&(f.prepareTx=function(a,b){var e,f;return a||0===d.length?void i.apply(c.API,[a,b]):void(b&&c.currSlide==c.slideCount-1?(f=d[0],d=d.slice(1),c.container.one("cycle-slide-added",function(a,b){setTimeout(function(){b.API.advanceSlide(1)},50)}),c.API.add(f)):b||0!==c.currSlide?i.apply(c.API,[a,b]):(e=d.length-1,f=d[e],d=d.slice(0,e),c.container.one("cycle-slide-added",function(a,b){setTimeout(function(){b.currSlide=1,b.API.advanceSlide(-1)},50)}),c.API.add(f,!0)))}),g&&(f.next=function(){var a=this.opts();if(d.length&&a.currSlide==a.slideCount-1){var b=d[0];d=d.slice(1),a.container.one("cycle-slide-added",function(a,b){g.apply(b.API),b.container.removeClass("cycle-loading")}),a.container.addClass("cycle-loading"),a.API.add(b)}else g.apply(a.API)}),h&&(f.prev=function(){var a=this.opts();if(d.length&&0===a.currSlide){var b=d.length-1,c=d[b];d=d.slice(0,b),a.container.one("cycle-slide-added",function(a,b){b.currSlide=1,b.API.advanceSlide(-1),b.container.removeClass("cycle-loading")}),a.container.addClass("cycle-loading"),a.API.add(c,!0)}else h.apply(a.API)})}})}(jQuery),/*! tmpl plugin for Cycle2;  version: 20121227 */
function(a){"use strict";a.extend(a.fn.cycle.defaults,{tmplRegex:"{{((.)?.*?)}}"}),a.extend(a.fn.cycle.API,{tmpl:function(b,c){var d=new RegExp(c.tmplRegex||a.fn.cycle.defaults.tmplRegex,"g"),e=a.makeArray(arguments);return e.shift(),b.replace(d,function(b,c){var d,f,g,h,i=c.split(".");for(d=0;d<e.length;d++)if(g=e[d]){if(i.length>1)for(h=g,f=0;f<i.length;f++)g=h,h=h[i[f]]||c;else h=g[c];if(a.isFunction(h))return h.apply(g,e);if(void 0!==h&&null!==h&&h!=c)return h}return c})}})}(jQuery);
//# sourceMappingURL=jquery.cycle2.js.map
/***************  templates/main/libs/jquery/cycle/jquery.cycle2.swipe.min.js  ***************/
/*! Plugin for Cycle2; Copyright (c) 2012 M. Alsup; ver: 20121120 */
(function(a){"use strict";var b="ontouchend"in document;a.event.special.swipe=a.event.special.swipe||{scrollSupressionThreshold:10,durationThreshold:1e3,horizontalDistanceThreshold:30,verticalDistanceThreshold:75,setup:function(){var b=a(this);b.bind("touchstart",function(c){function g(b){if(!f)return;var c=b.originalEvent.touches?b.originalEvent.touches[0]:b;e={time:(new Date).getTime(),coords:[c.pageX,c.pageY]},Math.abs(f.coords[0]-e.coords[0])>a.event.special.swipe.scrollSupressionThreshold&&b.preventDefault()}var d=c.originalEvent.touches?c.originalEvent.touches[0]:c,e,f={time:(new Date).getTime(),coords:[d.pageX,d.pageY],origin:a(c.target)};b.bind("touchmove",g).one("touchend",function(c){b.unbind("touchmove",g),f&&e&&e.time-f.time<a.event.special.swipe.durationThreshold&&Math.abs(f.coords[0]-e.coords[0])>a.event.special.swipe.horizontalDistanceThreshold&&Math.abs(f.coords[1]-e.coords[1])<a.event.special.swipe.verticalDistanceThreshold&&f.origin.trigger("swipe").trigger(f.coords[0]>e.coords[0]?"swipeleft":"swiperight"),f=e=undefined})})}},a.event.special.swipeleft=a.event.special.swipeleft||{setup:function(){a(this).bind("swipe",a.noop)}},a.event.special.swiperight=a.event.special.swiperight||a.event.special.swipeleft})(jQuery);
/***************  templates/main/libs/jquery/jquery.autoClear-min.js  ***************/
/*
	autoClear for jQuery (version 1.0)
	Copyright (c) 2009 Darsh
	
	Licensed under the MIT license:
		http://www.opensource.org/licenses/mit-license.php

	Any and all use of this script must be accompanied by this copyright/license notice in its present form.
*/
(function(a){a.fn.autoClear=function(b){var c={message:""};var d=a.extend(c,b);return this.each(function(f){var g=a(this);(d.message!="")?g.val(d.message):"";var e=g.val();g.bind("focus",function(){var h=a(this);var i=h.val();(i==e)?h.val(""):""});g.bind("blur",function(){var h=a(this);var i=h.val();(i=="")?h.val(e):""})})}})(jQuery);
/***************  templates/main/libs/jquery/jquery.inview.min.js  ***************/
!function(t){function e(){var e,i,n={height:a.innerHeight,width:a.innerWidth};return n.height||(e=r.compatMode,(e||!t.support.boxModel)&&(i="CSS1Compat"===e?f:r.body,n={height:i.clientHeight,width:i.clientWidth})),n}function i(){return{top:a.pageYOffset||f.scrollTop||r.body.scrollTop,left:a.pageXOffset||f.scrollLeft||r.body.scrollLeft}}function n(){var n,l=t(),r=0;if(t.each(d,function(t,e){var i=e.data.selector,n=e.$element;l=l.add(i?n.find(i):n)}),n=l.length)for(o=o||e(),h=h||i();n>r;r++)if(t.contains(f,l[r])){var a,c,p,s=t(l[r]),u={height:s.height(),width:s.width()},g=s.offset(),v=s.data("inview");if(!h||!o)return;g.top+u.height>h.top&&g.top<h.top+o.height&&g.left+u.width>h.left&&g.left<h.left+o.width?(a=h.left>g.left?"right":h.left+o.width<g.left+u.width?"left":"both",c=h.top>g.top?"bottom":h.top+o.height<g.top+u.height?"top":"both",p=a+"-"+c,v&&v===p||s.data("inview",p).trigger("inview",[!0,a,c])):v&&s.data("inview",!1).trigger("inview",[!1])}}var o,h,l,d={},r=document,a=window,f=r.documentElement,c=t.expando;t.event.special.inview={add:function(e){d[e.guid+"-"+this[c]]={data:e,$element:t(this)},l||t.isEmptyObject(d)||(l=setInterval(n,250))},remove:function(e){try{delete d[e.guid+"-"+this[c]]}catch(i){}t.isEmptyObject(d)&&(clearInterval(l),l=null)}},t(a).bind("scroll resize scrollstop",function(){o=h=null}),!f.addEventListener&&f.attachEvent&&f.attachEvent("onfocusin",function(){h=null})}(jQuery);
/***************  templates/main/libs/jquery/infobox_packed.js  ***************/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('7 8(a){a=a||{};r.s.1R.2k(2,3d);2.Q=a.1v||"";2.1H=a.1B||J;2.S=a.1G||0;2.H=a.1z||1h r.s.1Y(0,0);2.B=a.U||1h r.s.2E(0,0);2.15=a.13||t;2.1p=a.1t||"2h";2.1m=a.F||{};2.1E=a.1C||"3g";2.P=a.1j||"3b://38.r.33/2Y/2T/2N/1r.2K";3(a.1j===""){2.P=""}2.1f=a.1x||1h r.s.1Y(1,1);3(q a.A==="p"){3(q a.18==="p"){a.A=L}v{a.A=!a.18}}2.w=!a.A;2.17=a.1n||J;2.1I=a.2g||"2e";2.16=a.1l||J;2.4=t;2.z=t;2.14=t;2.V=t;2.E=t;2.R=t}8.9=1h r.s.1R();8.9.25=7(){5 i;5 f;5 a;5 d=2;5 c=7(e){e.20=L;3(e.1i){e.1i()}};5 b=7(e){e.30=J;3(e.1Z){e.1Z()}3(!d.16){c(e)}};3(!2.4){2.4=1e.2S("2Q");2.1d();3(q 2.Q.1u==="p"){2.4.O=2.G()+2.Q}v{2.4.O=2.G();2.4.1a(2.Q)}2.2J()[2.1I].1a(2.4);2.1w();3(2.4.6.D){2.R=L}v{3(2.S!==0&&2.4.Z>2.S){2.4.6.D=2.S;2.4.6.2D="2A";2.R=L}v{a=2.1P();2.4.6.D=(2.4.Z-a.W-a.11)+"12";2.R=J}}2.1F(2.1H);3(!2.16){2.E=[];f=["2t","1O","2q","2p","1M","2o","2n","2m","2l"];1o(i=0;i<f.1L;i++){2.E.1K(r.s.u.19(2.4,f[i],c))}2.E.1K(r.s.u.19(2.4,"1O",7(e){2.6.1J="2j"}))}2.V=r.s.u.19(2.4,"2i",b);r.s.u.T(2,"2f")}};8.9.G=7(){5 a="";3(2.P!==""){a="<2d";a+=" 2c=\'"+2.P+"\'";a+=" 2b=11";a+=" 6=\'";a+=" U: 2a;";a+=" 1J: 29;";a+=" 28: "+2.1E+";";a+="\'>"}K a};8.9.1w=7(){5 a;3(2.P!==""){a=2.4.3n;2.z=r.s.u.19(a,"1M",2.27())}v{2.z=t}};8.9.27=7(){5 a=2;K 7(e){e.20=L;3(e.1i){e.1i()}r.s.u.T(a,"3m");a.1r()}};8.9.1F=7(d){5 m;5 n;5 e=0,I=0;3(!d){m=2.1D();3(m 3l r.s.3k){3(!m.26().3h(2.B)){m.3f(2.B)}n=m.26();5 a=m.3e();5 h=a.Z;5 f=a.24;5 k=2.H.D;5 l=2.H.1k;5 g=2.4.Z;5 b=2.4.24;5 i=2.1f.D;5 j=2.1f.1k;5 o=2.23().3c(2.B);3(o.x<(-k+i)){e=o.x+k-i}v 3((o.x+g+k+i)>h){e=o.x+g+k+i-h}3(2.17){3(o.y<(-l+j+b)){I=o.y+l-j-b}v 3((o.y+l+j)>f){I=o.y+l+j-f}}v{3(o.y<(-l+j)){I=o.y+l-j}v 3((o.y+b+l+j)>f){I=o.y+b+l+j-f}}3(!(e===0&&I===0)){5 c=m.3a();m.39(e,I)}}}};8.9.1d=7(){5 i,F;3(2.4){2.4.37=2.1p;2.4.6.36="";F=2.1m;1o(i 35 F){3(F.34(i)){2.4.6[i]=F[i]}}2.4.6.32="31(0)";3(q 2.4.6.X!=="p"&&2.4.6.X!==""){2.4.6.2Z="\\"2X:2W.2V.2U(2R="+(2.4.6.X*1X)+")\\"";2.4.6.2P="2O(X="+(2.4.6.X*1X)+")"}2.4.6.U="2M";2.4.6.M=\'1c\';3(2.15!==t){2.4.6.13=2.15}}};8.9.1P=7(){5 c;5 a={1b:0,1g:0,W:0,11:0};5 b=2.4;3(1e.1s&&1e.1s.1W){c=b.2L.1s.1W(b,"");3(c){a.1b=C(c.1V,10)||0;a.1g=C(c.1U,10)||0;a.W=C(c.1T,10)||0;a.11=C(c.1S,10)||0}}v 3(1e.2I.N){3(b.N){a.1b=C(b.N.1V,10)||0;a.1g=C(b.N.1U,10)||0;a.W=C(b.N.1T,10)||0;a.11=C(b.N.1S,10)||0}}K a};8.9.2H=7(){3(2.4){2.4.2G.2F(2.4);2.4=t}};8.9.1y=7(){2.25();5 a=2.23().2C(2.B);2.4.6.W=(a.x+2.H.D)+"12";3(2.17){2.4.6.1g=-(a.y+2.H.1k)+"12"}v{2.4.6.1b=(a.y+2.H.1k)+"12"}3(2.w){2.4.6.M="1c"}v{2.4.6.M="A"}};8.9.2B=7(a){3(q a.1t!=="p"){2.1p=a.1t;2.1d()}3(q a.F!=="p"){2.1m=a.F;2.1d()}3(q a.1v!=="p"){2.1Q(a.1v)}3(q a.1B!=="p"){2.1H=a.1B}3(q a.1G!=="p"){2.S=a.1G}3(q a.1z!=="p"){2.H=a.1z}3(q a.1n!=="p"){2.17=a.1n}3(q a.U!=="p"){2.1q(a.U)}3(q a.13!=="p"){2.22(a.13)}3(q a.1C!=="p"){2.1E=a.1C}3(q a.1j!=="p"){2.P=a.1j}3(q a.1x!=="p"){2.1f=a.1x}3(q a.18!=="p"){2.w=a.18}3(q a.A!=="p"){2.w=!a.A}3(q a.1l!=="p"){2.16=a.1l}3(2.4){2.1y()}};8.9.1Q=7(a){2.Q=a;3(2.4){3(2.z){r.s.u.Y(2.z);2.z=t}3(!2.R){2.4.6.D=""}3(q a.1u==="p"){2.4.O=2.G()+a}v{2.4.O=2.G();2.4.1a(a)}3(!2.R){2.4.6.D=2.4.Z+"12";3(q a.1u==="p"){2.4.O=2.G()+a}v{2.4.O=2.G();2.4.1a(a)}}2.1w()}r.s.u.T(2,"2z")};8.9.1q=7(a){2.B=a;3(2.4){2.1y()}r.s.u.T(2,"21")};8.9.22=7(a){2.15=a;3(2.4){2.4.6.13=a}r.s.u.T(2,"2y")};8.9.2x=7(a){2.w=!a;3(2.4){2.4.6.M=(2.w?"1c":"A")}};8.9.2w=7(){K 2.Q};8.9.1A=7(){K 2.B};8.9.2v=7(){K 2.15};8.9.2u=7(){5 a;3((q 2.1D()==="p")||(2.1D()===t)){a=J}v{a=!2.w}K a};8.9.3i=7(){2.w=J;3(2.4){2.4.6.M="A"}};8.9.3j=7(){2.w=L;3(2.4){2.4.6.M="1c"}};8.9.2s=7(c,b){5 a=2;3(b){2.B=b.1A();2.14=r.s.u.2r(b,"21",7(){a.1q(2.1A())})}2.1N(c);3(2.4){2.1F()}};8.9.1r=7(){5 i;3(2.z){r.s.u.Y(2.z);2.z=t}3(2.E){1o(i=0;i<2.E.1L;i++){r.s.u.Y(2.E[i])}2.E=t}3(2.14){r.s.u.Y(2.14);2.14=t}3(2.V){r.s.u.Y(2.V);2.V=t}2.1N(t)};',62,210,'||this|if|div_|var|style|function|InfoBox|prototype||||||||||||||||undefined|typeof|google|maps|null|event|else|isHidden_|||closeListener_|visible|position_|parseInt|width|eventListeners_|boxStyle|getCloseBoxImg_|pixelOffset_|yOffset|false|return|true|visibility|currentStyle|innerHTML|closeBoxURL_|content_|fixedWidthSet_|maxWidth_|trigger|position|contextListener_|left|opacity|removeListener|offsetWidth||right|px|zIndex|moveListener_|zIndex_|enableEventPropagation_|alignBottom_|isHidden|addDomListener|appendChild|top|hidden|setBoxStyle_|document|infoBoxClearance_|bottom|new|stopPropagation|closeBoxURL|height|enableEventPropagation|boxStyle_|alignBottom|for|boxClass_|setPosition|close|defaultView|boxClass|nodeType|content|addClickHandler_|infoBoxClearance|draw|pixelOffset|getPosition|disableAutoPan|closeBoxMargin|getMap|closeBoxMargin_|panBox_|maxWidth|disableAutoPan_|pane_|cursor|push|length|click|setMap|mouseover|getBoxWidths_|setContent|OverlayView|borderRightWidth|borderLeftWidth|borderBottomWidth|borderTopWidth|getComputedStyle|100|Size|preventDefault|cancelBubble|position_changed|setZIndex|getProjection|offsetHeight|createInfoBoxDiv_|getBounds|getCloseClickHandler_|margin|pointer|relative|align|src|img|floatPane|domready|pane|infoBox|contextmenu|default|apply|touchmove|touchend|touchstart|dblclick|mouseup|mouseout|addListener|open|mousedown|getVisible|getZIndex|getContent|setVisible|zindex_changed|content_changed|auto|setOptions|fromLatLngToDivPixel|overflow|LatLng|removeChild|parentNode|onRemove|documentElement|getPanes|gif|ownerDocument|absolute|mapfiles|alpha|filter|div|Opacity|createElement|en_us|Alpha|Microsoft|DXImageTransform|progid|intl|MsFilter|returnValue|translateZ|WebkitTransform|com|hasOwnProperty|in|cssText|className|www|panBy|getCenter|http|fromLatLngToContainerPixel|arguments|getDiv|setCenter|2px|contains|show|hide|Map|instanceof|closeclick|firstChild'.split('|'),0,{}))
/***************  templates/main/libs/jquery/uniform/jquery.uniform.min.js  ***************/
!function(e,t,n){"use strict";function s(e){var t=Array.prototype.slice.call(arguments,1);return e.prop?e.prop.apply(e,t):e.attr.apply(e,t)}function a(e,t,n){var s,a;for(s in n)n.hasOwnProperty(s)&&(a=s.replace(/ |$/g,t.eventNamespace),e.bind(a,n[s]))}function r(e,t,n){a(e,n,{focus:function(){t.addClass(n.focusClass)},blur:function(){t.removeClass(n.focusClass),t.removeClass(n.activeClass)},mouseenter:function(){t.addClass(n.hoverClass)},mouseleave:function(){t.removeClass(n.hoverClass),t.removeClass(n.activeClass)},"mousedown touchbegin":function(){e.is(":disabled")||t.addClass(n.activeClass)},"mouseup touchend":function(){t.removeClass(n.activeClass)}})}function i(e,t){e.removeClass(t.hoverClass+" "+t.focusClass+" "+t.activeClass)}function l(e,t,n){n?e.addClass(t):e.removeClass(t)}function u(e,t,n){var s="checked",a=t.is(":"+s);t.prop?t.prop(s,a):a?t.attr(s,s):t.removeAttr(s),l(e,n.checkedClass,a)}function o(e,t,n){l(e,n.disabledClass,t.is(":disabled"))}function c(e,t,n){switch(n){case"after":return e.after(t),e.next();case"before":return e.before(t),e.prev();case"wrap":return e.wrap(t),e.parent()}return null}function d(e,n,a){var r,i,l;return a||(a={}),a=t.extend({bind:{},divClass:null,divWrap:"wrap",spanClass:null,spanHtml:null,spanWrap:"wrap"},a),r=t("<div />"),i=t("<span />"),n.autoHide&&e.is(":hidden")&&"none"===e.css("display")&&r.hide(),a.divClass&&r.addClass(a.divClass),n.wrapperClass&&r.addClass(n.wrapperClass),a.spanClass&&i.addClass(a.spanClass),l=s(e,"id"),n.useID&&l&&s(r,"id",n.idPrefix+"-"+l),a.spanHtml&&i.html(a.spanHtml),r=c(e,r,a.divWrap),i=c(e,i,a.spanWrap),o(r,e,n),{div:r,span:i}}function f(e,n){var s;return n.wrapperClass?(s=t("<span />").addClass(n.wrapperClass),s=c(e,s,"wrap")):null}function p(){var n,s,a,r;return r="rgb(120,2,153)",s=t('<div style="width:0;height:0;color:'+r+'">'),t("body").append(s),a=s.get(0),n=e.getComputedStyle?e.getComputedStyle(a,"").color:(a.currentStyle||a.style||{}).color,s.remove(),n.replace(/ /g,"")!==r}function m(e){return e?t("<span />").text(e).html():""}function v(){return navigator.cpuClass&&!navigator.product}function h(){return void 0!==e.XMLHttpRequest?!0:!1}function C(e){var t;return e[0].multiple?!0:(t=s(e,"size"),!t||1>=t?!1:!0)}function b(){return!1}function y(e,t){var n="none";a(e,t,{"selectstart dragstart mousedown":b}),e.css({MozUserSelect:n,msUserSelect:n,webkitUserSelect:n,userSelect:n})}function w(e,t,n){var s=e.val();""===s?s=n.fileDefaultHtml:(s=s.split(/[\/\\]+/),s=s[s.length-1]),t.text(s)}function g(e,t,n){var s,a;for(s=[],e.each(function(){var e;for(e in t)Object.prototype.hasOwnProperty.call(t,e)&&(s.push({el:this,name:e,old:this.style[e]}),this.style[e]=t[e])}),n();s.length;)a=s.pop(),a.el.style[a.name]=a.old}function k(e,t){var n;n=e.parents(),n.push(e[0]),n=n.not(":visible"),g(n,{visibility:"hidden",display:"block",position:"absolute"},t)}function H(e,t){return function(){e.unwrap().unwrap().unbind(t.eventNamespace)}}var x=!0,A=!1,W=[{match:function(e){return e.is("a, button, :submit, :reset, input[type='button']")},apply:function(t,n){var l,u,c,f,p;return u=n.submitDefaultHtml,t.is(":reset")&&(u=n.resetDefaultHtml),f=t.is("a, button")?function(){return t.html()||u}:function(){return m(s(t,"value"))||u},c=d(t,n,{divClass:n.buttonClass,spanHtml:f()}),l=c.div,r(t,l,n),p=!1,a(l,n,{"click touchend":function(){var n,a,r,i;p||t.is(":disabled")||(p=!0,t[0].dispatchEvent?(n=document.createEvent("MouseEvents"),n.initEvent("click",!0,!0),a=t[0].dispatchEvent(n),t.is("a")&&a&&(r=s(t,"target"),i=s(t,"href"),r&&"_self"!==r?e.open(i,r):document.location.href=i)):t.click(),p=!1)}}),y(l,n),{remove:function(){return l.after(t),l.remove(),t.unbind(n.eventNamespace),t},update:function(){i(l,n),o(l,t,n),t.detach(),c.span.html(f()).append(t)}}}},{match:function(e){return e.is(":checkbox")},apply:function(e,t){var n,s,l;return n=d(e,t,{divClass:t.checkboxClass}),s=n.div,l=n.span,r(e,s,t),a(e,t,{"click touchend":function(){u(l,e,t)}}),u(l,e,t),{remove:H(e,t),update:function(){i(s,t),l.removeClass(t.checkedClass),u(l,e,t),o(s,e,t)}}}},{match:function(e){return e.is(":file")},apply:function(e,n){function l(){w(e,p,n)}var u,f,p,m;return u=d(e,n,{divClass:n.fileClass,spanClass:n.fileButtonClass,spanHtml:n.fileButtonHtml,spanWrap:"after"}),f=u.div,m=u.span,p=t("<span />").html(n.fileDefaultHtml),p.addClass(n.filenameClass),p=c(e,p,"after"),s(e,"size")||s(e,"size",f.width()/10),r(e,f,n),l(),v()?a(e,n,{click:function(){e.trigger("change"),setTimeout(l,0)}}):a(e,n,{change:l}),y(p,n),y(m,n),{remove:function(){return p.remove(),m.remove(),e.unwrap().unbind(n.eventNamespace)},update:function(){i(f,n),w(e,p,n),o(f,e,n)}}}},{match:function(e){if(e.is("input")){var t=(" "+s(e,"type")+" ").toLowerCase(),n=" color date datetime datetime-local email month number password search tel text time url week ";return n.indexOf(t)>=0}return!1},apply:function(e,t){var n,a;return n=s(e,"type"),e.addClass(t.inputClass),a=f(e,t),r(e,e,t),t.inputAddTypeAsClass&&e.addClass(n),{remove:function(){e.removeClass(t.inputClass),t.inputAddTypeAsClass&&e.removeClass(n),a&&e.unwrap()},update:b}}},{match:function(e){return e.is(":radio")},apply:function(e,n){var l,c,f;return l=d(e,n,{divClass:n.radioClass}),c=l.div,f=l.span,r(e,c,n),a(e,n,{"click touchend":function(){t.uniform.update(t(':radio[name="'+s(e,"name")+'"]'))}}),u(f,e,n),{remove:H(e,n),update:function(){i(c,n),u(f,e,n),o(c,e,n)}}}},{match:function(e){return e.is("select")&&!C(e)?!0:!1},apply:function(e,n){var s,l,u,c;return n.selectAutoWidth&&k(e,function(){c=e.width()}),s=d(e,n,{divClass:n.selectClass,spanHtml:(e.find(":selected:first")||e.find("option:first")).html(),spanWrap:"before"}),l=s.div,u=s.span,n.selectAutoWidth?k(e,function(){g(t([u[0],l[0]]),{display:"block"},function(){var e;e=u.outerWidth()-u.width(),l.width(c+e),u.width(c)})}):l.addClass("fixedWidth"),r(e,l,n),a(e,n,{change:function(){u.html(e.find(":selected").html()),l.removeClass(n.activeClass)},"click touchend":function(){var t=e.find(":selected").html();u.html()!==t&&e.trigger("change")},keyup:function(){u.html(e.find(":selected").html())}}),y(u,n),{remove:function(){return u.remove(),e.unwrap().unbind(n.eventNamespace),e},update:function(){n.selectAutoWidth?(t.uniform.restore(e),e.uniform(n)):(i(l,n),u.html(e.find(":selected").html()),o(l,e,n))}}}},{match:function(e){return e.is("select")&&C(e)?!0:!1},apply:function(e,t){var n;return e.addClass(t.selectMultiClass),n=f(e,t),r(e,e,t),{remove:function(){e.removeClass(t.selectMultiClass),n&&e.unwrap()},update:b}}},{match:function(e){return e.is("textarea")},apply:function(e,t){var n;return e.addClass(t.textareaClass),n=f(e,t),r(e,e,t),{remove:function(){e.removeClass(t.textareaClass),n&&e.unwrap()},update:b}}}];v()&&!h()&&(x=!1),t.uniform={defaults:{activeClass:"active",autoHide:!0,buttonClass:"button",checkboxClass:"checker",checkedClass:"checked",disabledClass:"disabled",eventNamespace:".uniform",fileButtonClass:"action",fileButtonHtml:"Upload",fileClass:"uploader",fileDefaultHtml:"Select file",filenameClass:"filename",focusClass:"focus",hoverClass:"hover",idPrefix:"uniform",inputAddTypeAsClass:!0,inputClass:"uniform-input",radioClass:"radio",resetDefaultHtml:"Reset",resetSelector:!1,selectAutoWidth:!0,selectClass:"selector",selectMultiClass:"uniform-multiselect",submitDefaultHtml:"Submit",textareaClass:"uniform",useID:!0,wrapperClass:null},elements:[]},t.fn.uniform=function(n){var s=this;return n=t.extend({},t.uniform.defaults,n),A||(A=!0,p()&&(x=!1)),x?(n.resetSelector&&t(n.resetSelector).mouseup(function(){e.setTimeout(function(){t.uniform.update(s)},10)}),this.each(function(){var e,s,a,r=t(this);if(r.data("uniformed"))return t.uniform.update(r),void 0;for(e=0;e<W.length;e+=1)if(s=W[e],s.match(r,n))return a=s.apply(r,n),r.data("uniformed",a),t.uniform.elements.push(r.get(0)),void 0})):this},t.uniform.restore=t.fn.uniform.restore=function(e){e===n&&(e=t.uniform.elements),t(e).each(function(){var e,n,s=t(this);n=s.data("uniformed"),n&&(n.remove(),e=t.inArray(this,t.uniform.elements),e>=0&&t.uniform.elements.splice(e,1),s.removeData("uniformed"))})},t.uniform.update=t.fn.uniform.update=function(e){e===n&&(e=t.uniform.elements),t(e).each(function(){var e,n=t(this);e=n.data("uniformed"),e&&e.update(n,e.options)})}}(this,jQuery);
/***************  templates/main/libs/regnum.js  ***************/
var screenH = jQuery(window).height(),
	screenW = jQuery(window).width(),
	resizeEvent;

//set main visual height
function setVisualH() {
	var menuH = 0;
	menuH = jQuery("#header").height()+jQuery("#secondary-nav").height();
	jQuery("#main-visual-wrapper").height(screenH-jQuery("#header").height());
	jQuery(".main-visual,.main-visual .slideshow,.main-visual .slide").height(screenH-menuH);
}

// set holder top according to screen height
function setHolderT() {	
	jQuery("#holder").css("margin-top",jQuery(".main-visual").height());
}

// cookie bar height
function cookieH(){
	if(jQuery('#cookie-notice').length > 0 && jQuery('#cookie-notice').is(':visible')){
		var cookieblkH = jQuery("#cookie-notice").height();
		jQuery('.header-wrapper').css('top',cookieblkH);
	  }
}

function inviewImg(element){
	jQuery(element).on('inview', function(event, isInView) {
			var thisElement = jQuery(this),
				dataSrc = thisElement.data('url');

			if(isInView){
				thisElement.css('background-image', 'url(' + dataSrc + ')');
			}
	});
}

function maxH(element){
	//media logo
	//jQuery(element).removeAttr('style');
	var maxlogoH = 0;
	jQuery(element).each(function(){
		if (jQuery(this).height() > maxlogoH) { maxlogoH = $(this).height(); }
	});
	jQuery(element).height(maxlogoH);
}

/* Adding Uniform */
	jQuery('.flexibleForm select,.choose select,.type_fileDocument .fieldInput').uniform();

/* Adding min date to rfp form */
 jQuery(function() {
    jQuery( "#ff_eventStartDate1, #ff_arrivalDate1" ).datepicker({
      minDate:0,
      onSelect: function( selectedDate ) {
        jQuery( "#ff_eventFinalDate1, #ff_departureDate1" ).datepicker( "option", "minDate", selectedDate );
      }
    });
	
    jQuery( "#ff_eventFinalDate1, #ff_departureDate1" ).datepicker({    
      minDate:1,
		onSelect: function( selectedDate ) {
        jQuery( "#ff_eventStartDate1, #ff_arrivalDate1" ).datepicker( "option", "maxDate", selectedDate );
      }
	});
});

// Disable auto zoom in iphone
jQuery("input[type=text], input[type=select], textarea").on({ 'touchstart' : function() {
    zoomDisable();
}});
jQuery("input[type=text], input[type=select], textarea").on({ 'touchend' : function() {
    setTimeout(zoomEnable, 500);
}});

function zoomDisable(){
  jQuery('head meta[name=viewport]').remove();
  jQuery('head').prepend('<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />');
}
function zoomEnable(){
  jQuery('head meta[name=viewport]').remove();
  jQuery('head').prepend('<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />');
} 
	
//click on a tag
function clickhref(path){
	jQuery(path).click(function(){
		var currHref=jQuery(this).data('clickh');
		location.href=currHref;
	});
}

jQuery(document).ready(function(){
	if(!Modernizr.svg){
		jQuery('#branding img[src*="svg"]').attr('src', function() {
			return jQuery(this).attr('src').replace('.svg', '.png');
		});
		
		jQuery('body').addClass("no-svg");
	}
	
	//setVisualH();
	setHolderT();
	if(jQuery('body').hasClass('view-detail')){
		jQuery('#branding').appendTo('.view-item-logo');
	}

	cookieH();
	jQuery("div#cookie-notice a.close").bind("click", function(e){
		e.preventDefault();
		jQuery('.header-wrapper').css('top',0);
	});


	//language bar
	jQuery('.active-lang-code').text(jQuery('.lang-bar li.active').text());

	jQuery('.active-lang-code').click(function(){
		if(jQuery(this).hasClass('active')){
			jQuery(".lang-bar ul").slideUp();
			jQuery(this).removeClass('active');
		}else{
			jQuery(".lang-bar ul").slideDown();
			jQuery(this).addClass('active');
		}
	});


	//booking mask
	jQuery('.tmp-date-in').click(function(){
	 	jQuery("#date-in").focus();   
	});  
	jQuery('.tmp-date-out').click(function(){
	 	jQuery("#date-out").focus();   
	}); 
	jQuery('.choose .bg ').click(function(){
	 	jQuery(".choose select").focus();   
	}); 
	
	//booking mask
	if(!jQuery('body').hasClass('landing')){
	var tmpDateIn =jQuery('#date-in').val(),
	     dateInArray = tmpDateIn.split(',');
	     jQuery(".tmp-date-in .day").text(dateInArray[0]);
	     /* jQuery(".tmp-date-in .month").text(dateInArray[1]); */

	var tmpDateOut =jQuery('#date-out').val();
	    dateOutArray = tmpDateOut.split(',');
	     jQuery(".tmp-date-out .day").text(dateOutArray[0]);
	     /* jQuery(".tmp-date-out .month").text(dateOutArray[1]); */
	
	}
	
	//auto clear "Join mailing our list" type messages. requires the autoClear plugin. include the jquery.autoClear-min.js found in the libs/jquery directory in the inc.template.header-open.php file before using this code.
	if(jQuery().autoClear){				
		jQuery('#email-address,.fieldBlock.type_email .fieldInput').autoClear();
	}

	//home page hotel hightlights
	if(jQuery('body').hasClass('page_home')){

		jQuery(".highlight-item").each(function() {
			var curr_link=jQuery("a",this).attr('href'),
			    curr_target=jQuery("a",this).attr('target');
			jQuery(".link-trigger",this).data('href',curr_link);

			if(jQuery(".link-trigger",this).data('href')!=""){
				jQuery(".link-trigger",this).click(function(){ 
						if(curr_target=="_blank"){
							window.open(curr_link);
						}else{
						 	location.href=curr_link;
						}
				});
			}
		});

		if(!jQuery('body').hasClass('loggedIn')){

			jQuery(".highlight-item-intro").each(function() {
				var txt=jQuery(this).html();
				if(screenW>=1366){
					jQuery(this).html(txt.substr(0,200)+"<span class='more-txt'>{...}</span>");
				}else if(screenW>=1024 && screenW <= 1365){
					jQuery(this).html(txt.substr(0,140)+"<span class='more-txt'>{...}</span>");
				}
				jQuery(this).siblings('.portrait-highlight-item-intro').html(txt.substr(0,65)+"<span class='more-tx'> ...</span>");
				jQuery(this).siblings('.highlight-item-intro.mobile-only').html(txt.substr(0,65)+"<span class='more-tx'> ...</span>");
			});
		}	
			var hightlightItems=jQuery('.highlight-item');
			if(screenW>=768){
				for(var i=0;i<hightlightItems.length;i+=2){
					hightlightItems.slice(i,i+2).wrapAll("<div class='hightlight-itm-wrap'></div>");
				}
			}else{
				for(var i=0;i<hightlightItems.length;i+=1){
					hightlightItems.slice(i,i+1).wrapAll("<div class='hightlight-itm-wrap'></div>");
				}
				jQuery('.highlight-item').removeClass('even').addClass('odd');
			}

		jQuery('.highlights-rotator').cycle({
			slides: '.hightlight-itm-wrap',
			fx:     'scrollHorz',
			speed:  1000,
			timeout:0,
			pager: '.mainSliderControls .pages',
			prev:".prev-highlight",
			next:".next-highlight",
			swipe: true,
			pagerTemplate: '<div class="page-id">{{slideNum}}</div>'
		}); 
		
		
		packageReadMore(screenW);
		
			jQuery(".news-itm").each(function() {
				var titleTxt=jQuery('.news-title',this).text();
				if(titleTxt.length>45){
					var introTxt=jQuery('.news-intro',this).text();
					jQuery('.news-intro',this).html(introTxt.substr(0,75));
				}
			});
			
				jQuery(".reviews-item").each(function() {
					var introTxt=jQuery('.reviews-intro',this).text();
					if(screenW>=1024 && screenW<=1365){
						var titleTxt=jQuery('.item-title',this).text();
						var introTxt=jQuery('.reviews-intro',this).text();
						if(titleTxt.length>45){
							var introTxt=jQuery('.reviews-intro',this).text();
							jQuery('.reviews-intro',this).html(introTxt.substr(0,85));
						}
					}
					jQuery('.portrait-reviews-intro',this).html(introTxt.substr(0,120));
				});

		if(jQuery('.hightlight-itm-wrap').length<3){
			jQuery('.highlights-wrapper').addClass('no-nav');
		}

		//jQuery('.availability-checker-wrapper').delay(5000).animate({ opacity: 1, bottom: 0 }, 500);
		var top = $('html').offset().top;
		jQuery('.header-wrapper').delay(4500).animate({ opacity: 1, top: 0 }, 500);
		jQuery('.discover-btn').delay(4800).animate({ opacity: 1,'marginBottom':'0'}, 500);
		
	}
	// Main content read more functionality
	jQuery(".readmore-btn.read-less").click(function(){
		jQuery("html, body").animate({ scrollTop:0},1000);
	});	
	

	//when the page scroll
	jQuery(window).bind('scroll touchmove', function() {
		/* Hide calander when scrolling */
		 var calendarScroll = jQuery('#date-in').datepicker();
		 jQuery("#date-in,#date-out").blur(); 
		  jQuery('#date-out').datepicker('hide');
		calendarScroll.datepicker('hide');
			 
	   if (jQuery(this).scrollTop() > 200){
		   var top = $('html').scrollTop();
		   jQuery("body").addClass('scrolling');
		   jQuery('#branding,.lang-bar,.availability-checker-wrapper').fadeOut().stop(true,true); 
		   jQuery('.check-availability-link-btn,.scrolling-logo').fadeIn().stop(true,true);  
	   }else{
	   	jQuery("body").removeClass('scrolling');
	   	 jQuery('#branding,.lang-bar,.availability-checker-wrapper').fadeIn().stop(true,true); 
	   	 jQuery('.check-availability-link-btn,.scrolling-logo').fadeOut().stop(true,true); 
		 jQuery('.availability-checker-wrapper').animate({ opacity: 1, bottom: 0 }, 500);
	   }	   

			 			 
	});	

	jQuery(".discover-btn").click(function() {
	   var hT = jQuery('.main-visual').height();
	   jQuery("html, body").animate({ scrollTop: hT-45 },1000);
	});

	jQuery('.bestRateGuaranteed,.modifyBooking').clone().appendTo('.header');
	jQuery('.navigation ul').clone().appendTo('.menu-drop-down .main-menu');
	jQuery('.lang-bar').clone().appendTo('.lang-drop-down');



	
	jQuery('.menu-btn').click(function(){
		if(jQuery(this).hasClass('active')){
			jQuery(".non-desktop.menu-drop-down").slideUp();
			jQuery(this).removeClass('active');
		}else{
			jQuery(".non-desktop.menu-drop-down").slideDown();
			jQuery(this).addClass('active');
			jQuery("html, body").animate({ scrollTop:0 },1000);
		}
	});

	inviewImg('.inview-image');

	clickhref('.clickh');

	// Environment & Quality page 
	if(jQuery(".logo-content-wrp>div").hasClass("logo-image")){
	  jQuery("body").addClass("has-logo");	
	}
	// About Us page Slider
	if(jQuery(".main-container>div").hasClass("subpage-slider")){
	  jQuery("body").addClass("has-slider");	
	}
	// About Us page Pdf
	if(jQuery(".main-container>div").hasClass("downloads-block")){
	  jQuery("body").addClass("has-pdf");	
	}
	// About Us page read more
	var moreConH = jQuery(".page_aboutus .main-intro.more-content,.page_terms-and-conditions .main-intro.more-content,.page_packages .main-intro.more-content").height();
	if(moreConH > 380){
		jQuery("body").addClass('long-content');
		jQuery(".page_aboutus .about-us.read-more,.page_terms-and-conditions .about-us.read-more,.page_packages .about-us.read-more").click(function(){
			jQuery("body").removeClass('long-content');
			jQuery(".page_aboutus .about-us.read-more span.r-more,.page_terms-and-conditions .about-us.read-more span.r-more,.page_packages .about-us.read-more span.r-more").hide();
			jQuery(".page_aboutus .about-us.read-less span.r-less,.page_terms-and-conditions .about-us.read-less span.r-less,.page_packages .about-us.read-less span.r-less").show();
		});
		jQuery(".page_aboutus .about-us.read-less,.page_terms-and-conditions .about-us.read-less,.page_packages .about-us.read-less").click(function(){
			jQuery("html, body").animate({ scrollTop: 0 }, 500);
			jQuery("body").addClass('long-content');
			jQuery(".page_aboutus .about-us.read-less span.r-less,.page_terms-and-conditions .about-us.read-less span.r-less,.page_packages .about-us.read-less span.r-less").hide();
			jQuery(".page_aboutus .about-us.read-more span.r-more,.page_terms-and-conditions .about-us.read-more span.r-more,.page_packages .about-us.read-more span.r-more").show();
		});
	}
	// Contact Us page right content
	if(jQuery(".module-area>div").hasClass("contact-box-wrapper")){
	  jQuery("body").addClass("has-contactBox");	
	}
	
	var mobileW = jQuery(window).width();
	if(mobileW > 1023){
	var contactBoxH = jQuery(".has-contactBox .moduleOutput.showForm").outerHeight();
		jQuery(".has-contactBox .contact-box-wrapper").css('min-height',contactBoxH-20);
	}
		
	if(jQuery(".has-contactBox .fieldBlock").hasClass("invalid")){
		jQuery(".has-contactBox form.flexibleForm,.has-contactBox .contact-box-wrapper").addClass("invalid-form");
	}
	//Career page form
	if(jQuery("form.flexibleForm>div").hasClass("career")){
	  jQuery("body").addClass("careerForm");	
	}
	jQuery(".careerForm form.flexibleForm .uploader").append("<div></div>");
	jQuery(".careerForm form.flexibleForm .uploader div").addClass("upload-seperator");
	
	if(jQuery(".careerForm form.flexibleForm .fieldBlock").hasClass('invalid')){
		jQuery("body").addClass("unsuccess-request");	
	}
		//var formAction=jQuery(".page_career .flexibleForm").attr("action");
		//jQuery(".page_career .flexibleForm").attr("action",formAction+"#career-form");	
	
	//mobile read more

	// var mobIntro=jQuery('.more-content p').text();
	// if(mobIntro.length>40){
	// 	jQuery('.mob-readmore-intro p').html(mobIntro.substr(0,145)+"<span>...</span>");
	// }else{
	// 	jQuery('.mob-readmore-intro p').html(mobIntro);
	// }
	// jQuery('.readmore-btn.read-more').click(function(){
	// 	jQuery('.mob-readmore-intro').slideUp('slow');
	// 	jQuery('.more-content').slideDown('slow');
	// });
	// jQuery('.readmore-btn.read-less').click(function(){
	// 	jQuery('.mob-readmore-intro').slideDown('slow');
	// 	jQuery('.more-content').slideUp('slow');
	// });

	//read more

	// jQuery('.readmore-btn').click(function(){
	// 	jQuery('.readMoreContent').slideDown('slow');
	// 	jQuery('.main-content').addClass('open');	
	// });
	// jQuery('.read-less').click(function(){
	// 	jQuery('.main-content').removeClass('open');
	// 	jQuery('.readMoreContent').slideUp('slow');
	// 	$('html, body').animate({
	// 	        scrollTop: $("#home-container").offset().top
	// 	    }, 2000);
	// });
	
	jQuery('.readmore-btn').click(function(){
		$("#Slider").toggleClass("slidedown slideup");
		jQuery('.main-content').addClass('open');
	});	
	jQuery('.read-less').click(function(){
		$("#Slider").toggleClass("slidedown slideup");
		jQuery('.main-content').removeClass('open');
		$('html, body').animate({
        scrollTop: $("#home-container").offset().top
   		}, 500);
	});

	
	  

	//gallery page
	
	jQuery('.fllter-label').click(function(){
		if(jQuery(this).hasClass('active')){
			jQuery(".fliter-list").slideUp();
			jQuery(this).removeClass('active');
		}else{
			jQuery(".fliter-list").slideDown();
			jQuery(this).addClass('active');
		}
	});

	
	//cookie bar
	if(jQuery('#cookie-notice').length>0){
		jQuery('body').addClass('has-cookie');
		if(jQuery('body').hasClass('view-detail')){
			jQuery('.header-wrapper').css('margin-top',0);
			jQuery('.main-visual').css('top',(jQuery('#cookie-notice').height()));
			jQuery('#holder').css('padding-top',(jQuery('#cookie-notice').height()));
			
			if(screenW<768){
			jQuery('.check-availability-link-btn').css('top',(jQuery('#cookie-notice').height()));
			jQuery('.header-wrapper').css('margin-top',(jQuery('#cookie-notice').height()));
			}
			
		}else{
			if(jQuery('body').hasClass('page_home')){
				jQuery('.header-wrapper').css('margin-top',jQuery('#cookie-notice').height());
			}else{
				jQuery('.header-wrapper').css('margin-top',0);
			}
		}
		
	}
	
	jQuery('#cookie-notice .close').click(function(){
		jQuery('.header-wrapper').css('margin-top',0);
		jQuery('.main-visual').css('top',0);
		jQuery('#holder').css('padding-top',0);
		if(screenW<768){
			jQuery('.check-availability-link-btn').css('top',0);
		}
		jQuery('body').removeClass('has-cookie');
	});
	
	
	if(jQuery('body').hasClass('view-detail') && !jQuery('body').hasClass('page_career')){
		jQuery('.cat-title').click(function(){
			var currAcc=jQuery(this).parent(),
				catID=jQuery(this).attr('data-catid');

			if(jQuery(this).hasClass('active')){
				//if(!jQuery('.'+catID+' .dropdown-menu-item').hasClass('active')){
					jQuery(".cat-list",currAcc).slideUp();
					jQuery(".cat-title."+catID).removeClass('active');
					//jQuery(".cat-list",currAcc).removeClass('active');
					jQuery(this).removeClass('active');

				//}
			}else{
				jQuery(".cat-list",currAcc).slideDown();
				jQuery(this).addClass('active');
				jQuery(".cat-title."+catID).addClass('active');

			}
			
			jQuery('.dropdown-cat').each(function(){
				if(jQuery('.cat-title',this).hasClass('active')){
					jQuery('.cat-list',this).addClass('active');
				}else{
				//jQuery('.cat-list',this).removeClass('active');
				}
			});

		});
	}
	
	
	
	
	maxH(".brand-logo");
	maxH(".press-pdf");
	maxH(".plan-pdf");
	
	if(jQuery('.moduleOutput').hasClass("viewItem")){
		jQuery('.main-container-wrapper').remove();
	}
	
	if(jQuery('body').hasClass('page_guest-book') && jQuery(window).width()<768){
		jQuery('.mod-items .cat-title').click(function(){
		var curr=jQuery(this).parent();
			if(jQuery(this).hasClass('active')){
				jQuery(this).parent().addClass('active');
				jQuery('.mod-items .cat-items-list.active .cat-items').slideDown();
			}else{
				jQuery(this).parent().children('.cat-items').slideUp();
				jQuery(this).parent().removeClass('active');
			}
			
			//alret("hi");
		});
		
	}
	
	if(jQuery('body').hasClass('page_home') && jQuery(window).width()<768){
		jQuery("html, body").animate({ scrollTop:0},1000);
		
	}
	/* DISABLE CYCLE LOGS */
	jQuery.fn.cycle.log = jQuery.noop	

	jQuery('.bestRateGuaranteed').click(function(){
		jQuery('.best-rate-content-wrapper').addClass('active');
	});
	jQuery('.best-rate-close').click(function(){
		jQuery('.best-rate-content-wrapper').removeClass('active');
	});

});

	function packageReadMore(screenW){
		jQuery(".package-itm").each(function() {
			var titleTxt=jQuery('.itm-title',this).text();
			var titleH=jQuery('.itm-title',this).height();
			
			if(screenW>=1366){
				if(titleH>35){
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,45)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('line-txt');
				}else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,80)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('less-txt');
				}
			}else if(screenW>=1024 && screenW<=1365){
				if(titleH>35){
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,30)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('line-txt');
				}else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,60)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('less-txt');
				}
				/*else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,80)+"<span class='more-txt'>{...}</span>");
				}*/

			}else if(screenW>=768 && screenW<=1023){
				if(titleH>35){
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,30)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('line-txt');
					
				}else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,60)+"<span class='more-txt'>{...}</span>");
					jQuery('.itm-intro',this).addClass('less-txt');
					
				}
				/*else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,70)+"<span class='more-txt'>{...}</span>");
				}*/

			}
			else{
					var introTxt=jQuery('.itm-intro',this).text();
					jQuery('.itm-intro',this).html(introTxt.substr(0,78)+"<span class='more-txt'>{...}</span>");
			}
		});
	}

jQuery(window).on('load',function() {

	jQuery('.gallery-block .item-img-slide.fancy-image.cycle-sentinel').remove();
	if(!jQuery('body').hasClass('landing')){
	//booking mask
	var tmpDateIn =jQuery('#date-in').val(),
	     dateInArray = tmpDateIn.split(',');
	     jQuery(".tmp-date-in .day").text(dateInArray[0]);
	     /* jQuery(".tmp-date-in .month").text(dateInArray[1]); */

	var tmpDateOut =jQuery('#date-out').val();
	    dateOutArray = tmpDateOut.split(',');
	     jQuery(".tmp-date-out .day").text(dateOutArray[0]);
	     /* jQuery(".tmp-date-out .month").text(dateOutArray[1]); */
	}
	//weather
	jQuery('.weather-day-0').text(jQuery('.weather-date0').text());
	jQuery('.weather-day-1').text(jQuery('.weather-date1').text());

	if(!jQuery('body').hasClass('loggedIn')){
		jQuery(".hightlight-content a").each(function(){
			var attr = $(this).attr('href');
			if (typeof attr !== typeof undefined && attr !== false) {
			    jQuery(this).show();
			}else{
				jQuery(this).remove();
				jQuery(this).parent().parent().addClass('no-link');
			}
		});
	}
	jQuery('.lang-drop-down .active-lang-code').click(function(){
		if(jQuery(this).hasClass('active')){
			jQuery(".lang-bar ul").slideUp();
			jQuery(this).removeClass('active');
			jQuery('.lang-drop-down').removeClass('lang-open');
		}else{
			jQuery(".lang-bar ul").slideDown();
			jQuery(this).addClass('active');
			jQuery('.lang-drop-down').addClass('lang-open');
		}
	});
	
	//media logo
	maxH(".brand-logo");
	jQuery('.media-press-releases.cat-items-list .cat-items,.media-plans-brochures.cat-items-list .cat-items').css({
			   'visibility' : 'hidden',
			   'display' : 'block'
			});
	maxH(".press-pdf");
	maxH(".plan-pdf");
	jQuery('.media-press-releases.cat-items-list .cat-items,.media-plans-brochures.cat-items-list .cat-items').removeAttr('style');
	
});




//Screen resize
jQuery(window).resize(function() {
	var screenH = jQuery(window).height(),
		screenW = jQuery(window).width();

	//setVisualH();
	setHolderT();
	cookieH();
		clearTimeout(resizeEvent);
		resizeEvent = setTimeout(resizingEvent, 500);

	
});

function resizingEvent(){
    //cookie bar
	if(jQuery('#cookie-notice').length>0 && jQuery('body').hasClass('has-cookie')){
		if(jQuery('body').hasClass('view-detail')){
			jQuery('.header-wrapper').css('margin-top',0);
			jQuery('.main-visual').css('top',(jQuery('#cookie-notice').height()));
			jQuery('#holder').css('padding-top',(jQuery('#cookie-notice').height()));
			
			if(screenW<768){
			jQuery('.check-availability-link-btn').css('top',(jQuery('#cookie-notice').height()));
			jQuery('.header-wrapper').css('margin-top',(jQuery('#cookie-notice').height()));
			}else{
				jQuery('.header-wrapper').css('margin-top',0);
			}
			
		}else{
			jQuery('.header-wrapper').css('margin-top',0);
		}
		
	}
	
	
}

jQuery( window ).on( "orientationchange", function( event ) {
	
	var screenW = jQuery(window).width();
	setTimeout(function(){
		packageReadMore(screenW);
	},1000);
	
	maxH(".brand-logo");
	maxH(".press-pdf");
	maxH(".plan-pdf");
	jQuery(".fliter-list .item-Preview").each(function(){
		jQuery(this).appendTo('.fliter-list');	
		jQuery('.fliter-list .attractions-itm-wrap').remove();
	});
	/*if(jQuery(window).width()>768){			
			var tmpAttitmLength=jQuery('.fliter-list .item-Preview').length/3;
				attractionsItems=jQuery('.fliter-list .item-Preview')
			for(var i=0;i<attractionsItems.length;i+=tmpAttitmLength){
				attractionsItems.slice(i,i+tmpAttitmLength).wrapAll("<div class='attractions-itm-wrap'></div>");
			}
	}else{
		var tmpAttitmLength=jQuery('.fliter-list .item-Preview').length/2;
				attractionsItems=jQuery('.fliter-list .item-Preview')
			for(var i=0;i<attractionsItems.length;i+=tmpAttitmLength){
				attractionsItems.slice(i,i+tmpAttitmLength).wrapAll("<div class='attractions-itm-wrap'></div>");
			}
	}*/
	
	if(jQuery("#date-in").datepicker( "widget" ).is(":visible")){
	  console.log('show');  
   }
   
	
});